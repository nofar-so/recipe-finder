package com.example.recipe_finder.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.Ingredients;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ManagerAddIngredients extends AppCompatActivity {

    EditText etIngredientNameAdd;
    Button btnAddIngredient;
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://recipefinder-63cc6557-default-rtdb.firebaseio.com/");
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manager_add_ingredients);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnAddIngredient = findViewById(R.id.btnAddIngredient);
        etIngredientNameAdd = findViewById(R.id.etIngredientNameAdd);

        btnAddIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ingredientName = etIngredientNameAdd.getText().toString();
                if (ingredientName.equals("")) {
                    Toast.makeText(ManagerAddIngredients.this, "נא להוסיף שם לפריט", Toast.LENGTH_SHORT).show();
                } else {
                    // Push new ingredient to Firebase
                    myRef = database.getReference("Ingredients").push();
                    Ingredients ingredients = new Ingredients(myRef.getKey(), ingredientName, 0);
                    myRef.setValue(ingredients);

                    // Show a message with the name of the added ingredient
                    Toast.makeText(ManagerAddIngredients.this, ingredientName + " was added", Toast.LENGTH_SHORT).show();

                    // Optionally, clear the EditText after adding the ingredient
                    etIngredientNameAdd.setText("");
                }
            }
        });
    }
}
