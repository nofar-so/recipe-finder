package com.example.recipe_finder.moodle;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.recipe_finder.ui.ManagerMain;
import com.example.recipe_finder.R;
import com.example.recipe_finder.ui.ManagerMain;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class FireBaseNotification extends Service {
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://recipe_finder-default-rtdb.firebaseio.com/"); //An object that points to the database
    DatabaseReference myRef = database.getReference(); //An object that points to a certain thing in the database and helps us levatzea peulot in the database
    Notification notification;
    private static final int REQUEST_NOTIFICATION_PERMISSION = 1;

    NotificationCompat.Builder builder; //bone et a  message displayed to the user: title, content, icon
    NotificationManagerCompat notificationManager; //Manages the message, clomar it means that he  responsible for the message being displayed on the phone and when
    Query q; //Query type (this is shailta). Another way to levatzea peulot on the database instead of the reference
    private ManagerMain mainActivity;



    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "YOUR_CHANNEL_ID";
            NotificationChannel channel = new NotificationChannel(channelId,
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_DEFAULT);
            //Creates the channel where the message will be displayed
            notificationManager = NotificationManagerCompat.from(this);
            notificationManager.createNotificationChannel(channel);
            builder = new NotificationCompat.Builder(this, channelId).setContentTitle("new order!").setContentText("a user ordered something").setSmallIcon(R.drawable.logo1);
            builder.setChannelId(channelId);
            builder.setDefaults(NotificationCompat.DEFAULT_ALL);
            notificationManager = NotificationManagerCompat.from(this);
        }


    }

    public int onStartCommand(Intent intent, int flags, int startId){
        q = myRef.child("Orders").orderByValue();
        //A listener waiting for a change in one of the summaries or a new summary to appear
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //mainActivity = MainActivity.getMainActivity();
                startForeground(1, builder.build());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}