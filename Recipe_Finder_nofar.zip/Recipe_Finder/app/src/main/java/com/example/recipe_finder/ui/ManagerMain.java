package com.example.recipe_finder.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.FireBaseNotification;

public class ManagerMain extends AppCompatActivity {

    Button btnGoToIngredientsList, btnRecipeList, btnGoToUserList, btnCancelledUsers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manager_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        
        btnGoToIngredientsList = findViewById(R.id.btnGoToIngredientsList);
        btnGoToUserList = findViewById(R.id.btnGoToUserList);
        btnCancelledUsers = findViewById(R.id.btnCancelledUsers);
        btnRecipeList = findViewById(R.id.btnGoToRecipeList);
        btnRecipeList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("manager main", "1");
                Intent intent = new Intent(ManagerMain.this, ManagerRecipeList.class);
                startActivity(intent);
            }
        });
        btnGoToIngredientsList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManagerMain.this, ManagerIngredientsList.class);
                startActivity(intent);
            }
        });

        btnGoToUserList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerMain.this, ManagerUsersList.class);
                startActivity(intent);
            }
        });

        btnCancelledUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerMain.this, ManagerCancelledUsers.class);
                startActivity(intent);

            }
        });


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.manager_menu,menu);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.recipe_list) {
            Intent intent = new Intent(this, ManagerRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.add_recipe) {
            Intent intent = new Intent(this, ManagerAddRecipe.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_list) {
            Intent intent = new Intent(this, ManagerUsersList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.cancelled_users) {
            Intent intent = new Intent(this, ManagerCancelledUsers.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_main) {
            Intent intent = new Intent(this, ManagerMain.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}