package com.example.recipe_finder.moodle;

import java.util.ArrayList;

public class User extends Person {
    private int favoriteCount;

    public User(String id, String fName, String lName, String email, String password, String phone, String type) {
        super(id, fName, lName, email, password, phone, type);
        this.favoriteCount = 0;
    }


    public User() {
        // Default constructor
    }

    public int getFavorites() {
        return favoriteCount;
    }

    public void setFavorites(int favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    @Override
    public String toString() {
        return "User{" +
                "favorites=" + favoriteCount +
                '}';
    }

    public void addFavorite() {
        this.favoriteCount++;
    }
    public void removeFavorite() {
        this.favoriteCount--;
    }


}

