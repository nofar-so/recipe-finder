package com.example.recipe_finder.moodle;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.recipe_finder.R;

import java.util.ArrayList;
import java.util.List;

public class AdapterRecipes extends ArrayAdapter<Recipe> {
    Context context;//העמוד שממנו היתה הקריאה לאדפטר
    List<Recipe> objects;//רשימה של קבצי התמונה
    ArrayList<String> fav;

    public AdapterRecipes(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<Recipe> objects, ArrayList<String> fav) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
        this.fav = fav;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = ((Activity)context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.recipe_list, parent, false);

        TextView tvRecipeNameList = view.findViewById(R.id.tvRecipeNameList);
        TextView tvRecipeIngredientsList = view.findViewById(R.id.tvRecipeIngredientsList);
        ImageView ivList = view.findViewById(R.id.ivList);


        Recipe temp = objects.get(position);
        Log.d("favAdapter", fav.size()+"");
        Log.d("favAdapter", fav.contains(temp.getId())+"");
        if(fav.contains(temp.getId())){
            tvRecipeNameList.setTextColor(Color.RED);
        } else {
            tvRecipeNameList.setTextColor(Color.WHITE); // Reset to default if not favorite
        }

        tvRecipeNameList.setText(temp.getName());
        String ingredients = "מצרכים: " + temp.getIngredients().size();

        tvRecipeIngredientsList.setText(ingredients);
        if(temp.getImage()!=null && !temp.getImage().equals("")) {
            Bitmap bitmap = convert64base(temp.getImage());
            ivList.setImageBitmap(bitmap);
        }
        return view;
    }
    public Bitmap convert64base(String base64Code) {
        byte[] decodedString = Base64.decode(base64Code, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }
}
