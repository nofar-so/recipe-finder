package com.example.recipe_finder.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextWatcher;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.AdapterRecipes;
import com.example.recipe_finder.moodle.Ingredients;
import com.example.recipe_finder.moodle.Recipe;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ManagerRecipeList extends AppCompatActivity {

    EditText etSearchRecipeListManager;
    ListView lvRecipeListManager;
    Button btnAddRecipeManager;
    private DatabaseReference database, deleteRef;
    ArrayList<Recipe> recipes, search;
    AdapterRecipes adapterRecipes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manager_recipe_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        search= new ArrayList<>();
        Log.d("recipe list", "1");
        btnAddRecipeManager = findViewById(R.id.btnAddRecipeManager);
        lvRecipeListManager = findViewById(R.id.lvRecipeListManager);
        etSearchRecipeListManager = findViewById(R.id.etSearchRecipeListManager);
        recipes = new ArrayList<>();

        database = FirebaseDatabase.getInstance().getReference("Recipes");
        Log.d("recipe list", "2");
        btnAddRecipeManager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerRecipeList.this, ManagerAddRecipe.class);
                startActivity(intent);
            }
        });


        retriveData();
    }
    private void retriveData() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d("recipe list", "3");
                recipes = new ArrayList<>();
                for(DataSnapshot data : dataSnapshot.getChildren())
                {
                    Recipe r = data.getValue(Recipe.class);
                    recipes.add(r);

                }
                Log.d("recipe list", "4");
                search= recipes;
                adapterRecipes = new AdapterRecipes(ManagerRecipeList.this,0,0,search, new ArrayList<String>());
                lvRecipeListManager.setAdapter(adapterRecipes);
                Log.d("recipe list", "5");

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        lvRecipeListManager.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(ManagerRecipeList.this, ManagerUpdateRecipe.class);
                intent.putExtra("recipeId", search.get(i).getId());
                startActivity(intent);
            }
        });
        lvRecipeListManager.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteRef = FirebaseDatabase.getInstance().getReference("Recipes").child(search.get(position).getId());
                deleteRef.removeValue();

                return false;
            }
        });

        etSearchRecipeListManager.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etSearchRecipeListManager.getText().toString();
                search = new ArrayList<>();
                for(int j = 0; j < recipes.size(); j++) {
                    if(recipes.get(j).getName().contains(txt)) {
                        search.add(recipes.get(j));
                    }
                }
                adapterRecipes = new AdapterRecipes(ManagerRecipeList.this, 0, 0, search, new ArrayList<String>());
                lvRecipeListManager.setAdapter(adapterRecipes);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // No action needed here
            }
        });


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.manager_menu,menu);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.recipe_list) {
            Intent intent = new Intent(this, ManagerRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.add_recipe) {
            Intent intent = new Intent(this, ManagerAddRecipe.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_list) {
            Intent intent = new Intent(this, ManagerUsersList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.cancelled_users) {
            Intent intent = new Intent(this, ManagerCancelledUsers.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_main) {
            Intent intent = new Intent(this, ManagerMain.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}