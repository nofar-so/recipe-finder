package com.example.recipe_finder.ui;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.Ingredients;
import com.example.recipe_finder.moodle.Recipe;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;

public class UserAddRecipe extends AppCompatActivity {

    SharedPreferences sp;
    String type;
    Button btnUserAddRecipe, btnAddImageUser, btnCameraAddRecipeUser, btnGalleryAddRecipeUser;
    ListView lvUserIngredientsList, lvIngredientsInRecipeUser;
    EditText etUserName, etUserSearchIngredientAddRecipe, etUserPreparationMethod;
    ArrayList<Ingredients> ingredients, ingredientsInRecipe;
    private DatabaseReference database, recipeRef;
    ArrayList<Ingredients> search;
    AdapterIngredient adapterIngredient, adapterIngredientInRecipe;
    ConstraintLayout llListUser, llImageUser;

    Dialog dialogAddImage;
    ImageView ivAddImageUser;
    ActivityResultLauncher<String> arlFromGallery;
    ActivityResultLauncher<Intent> arlMakePhoto;
    Uri imageUri;
    private String mCurrentPhotoPath;
    File imageFile;
    Bitmap bitmap;
    String picToString="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_add_recipe);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        sp = getSharedPreferences("details1", 0);
        type = sp.getString("type", "");
        btnUserAddRecipe = findViewById(R.id.btnUserAddRecipe);
        etUserSearchIngredientAddRecipe = findViewById(R.id.etUserSearchIngredientAddRecipe);
        etUserName = findViewById(R.id.etUserNameUpdate);
        etUserPreparationMethod = findViewById(R.id.etUserPreparationMethodUpdate);

        lvUserIngredientsList = findViewById(R.id.lvUserIngredientsList);
        lvIngredientsInRecipeUser = findViewById(R.id.lvIngredientsInRecipeUser);
        btnAddImageUser = findViewById(R.id.btnAddImageUser);

        llImageUser = findViewById(R.id.llImageUser);
        llListUser  = findViewById(R.id.llListUser);

        btnCameraAddRecipeUser = findViewById(R.id.btnCameraAddRecipeUser);
        btnGalleryAddRecipeUser = findViewById(R.id.btnGalleryAddRecipeUser);
        ivAddImageUser = findViewById(R.id.ivAddImageUser);

        btnCameraAddRecipeUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentMakePhoto=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                arlMakePhoto.launch(intentMakePhoto);
            }
        });
        btnGalleryAddRecipeUser.setOnClickListener(v-> arlFromGallery.launch("image/*"));
        try {
            imageUri=createUri();



        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        ingredients = new ArrayList<>();
        ingredientsInRecipe = new ArrayList<>();
        database = FirebaseDatabase.getInstance().getReference("Ingredients");

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE}, 100);

        arlMakePhoto=registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode()==RESULT_OK && result.getData()!=null) {
                            Bundle bundle = result.getData().getExtras();
                            bitmap = (Bitmap)bundle.get("data");
                            ivAddImageUser.setImageBitmap(bitmap);
                            picToString=convertTo64Base(ivAddImageUser);
                        }
                    }
                }
        );

        arlFromGallery=registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri result) {
                        if (result!=null) {
                            try {
                                final InputStream imageStream = getContentResolver().openInputStream(result);
                                Log.d("URI", result.toString() + "");
                                bitmap = BitmapFactory.decodeStream(imageStream);
                                Log.d("URI", bitmap + "");
                                ivAddImageUser.setImageURI(result);
                                picToString=convertTo64Base(ivAddImageUser);

                            }
                            catch (FileNotFoundException e){
                                e.printStackTrace();
                                Toast.makeText(UserAddRecipe.this, "Something went wrong", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }
        );

        btnAddImageUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnAddImageUser.getText().toString().toLowerCase().contains("image")){
                    llImageUser.setVisibility(View.VISIBLE);
                    llListUser.setVisibility(View.INVISIBLE);
                    btnAddImageUser.setText("choose ingredients");
                }
                else{
                    llImageUser.setVisibility(View.INVISIBLE);
                    llListUser.setVisibility(View.VISIBLE);
                    btnAddImageUser.setText("Add Image");
                }




            }
        });

        btnUserAddRecipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etUserName.getText().toString().equals("") || etUserPreparationMethod.getText().toString().equals("") || ingredientsInRecipe.size()==0 || picToString.equals("")){
                    Toast.makeText(UserAddRecipe.this, "לא מילאת כל השדות", Toast.LENGTH_LONG).show();
                }
                else{
                    recipeRef = FirebaseDatabase.getInstance().getReference("Recipes").push();
                    Recipe recipe = new Recipe(recipeRef.getKey(), etUserName.getText().toString(), ingredientsInRecipe, etUserPreparationMethod.getText().toString(), sp.getString("uid", ""), picToString);
                    recipeRef.setValue(recipe);
                    Intent intent = new Intent(UserAddRecipe.this, MainUser.class);
                    startActivity(intent);
                }

            }
        });
        etUserSearchIngredientAddRecipe.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etUserSearchIngredientAddRecipe.getText().toString();
                search = new ArrayList<>();
                for (int j = 0; j < ingredients.size(); j++) {
                    if (ingredients.get(j).getName().contains(txt))
                        search.add(ingredients.get((j)));
                }
                adapterIngredient = new AdapterIngredient(UserAddRecipe.this, 0, 0, search);
                lvUserIngredientsList.setAdapter(adapterIngredient);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        lvUserIngredientsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ingredients ingredient = search.get(position);
                boolean isExist = false;
                for(int i=0;i<ingredientsInRecipe.size();i++){
                    if(ingredientsInRecipe.get(i).getId().equals(ingredient.getId())){
                        ingredientsInRecipe.get(i).setAmount(ingredientsInRecipe.get(i).getAmount()+1);
                        isExist = true;
                    }
                }
                if(!isExist) {
                    ingredient.setAmount(1);
                    ingredientsInRecipe.add(ingredient);
                }
                adapterIngredientInRecipe = new AdapterIngredient(UserAddRecipe.this, 0, 0, ingredientsInRecipe);
                lvIngredientsInRecipeUser.setAdapter(adapterIngredientInRecipe);

            }
        });
        lvIngredientsInRecipeUser.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(ingredientsInRecipe.get(position).getAmount()>1) {
                    ingredientsInRecipe.get(position).setAmount(ingredientsInRecipe.get(position).getAmount() - 1);

                }
                else if(ingredientsInRecipe.get(position).getAmount()<=1){
                    ingredientsInRecipe.remove(position);
                }
                adapterIngredientInRecipe = new AdapterIngredient(UserAddRecipe.this, 0, 0, ingredientsInRecipe);
                lvIngredientsInRecipeUser.setAdapter(adapterIngredientInRecipe);
            }
        });
//        lvIngredientsInRecipe.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
//            @Override
//            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//
//                if(ingredientsInRecipe.get(position).getAmount()>0) {
//                    ingredientsInRecipe.get(position).setAmount(ingredientsInRecipe.get(position).getAmount() - 1);
//
//                }
//                else if(ingredientsInRecipe.get(position).getAmount()==0){
//                    ingredientsInRecipe.remove(position);
//                }
//                adapterIngredientInRecipe = new AdapterIngredient(ManagerAddRecipe.this, 0, 0, ingredientsInRecipe);
//                lvIngredientsInRecipe.setAdapter(adapterIngredientInRecipe);
//                return false;
//            }
//        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });





        retriveData();

    }
    private void retriveData() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                ingredients = new ArrayList<>();
                for(DataSnapshot data : dataSnapshot.getChildren())
                {
                    Ingredients i = data.getValue(Ingredients.class);
                    ingredients.add(i);

                }
                search = ingredients;
                adapterIngredient = new AdapterIngredient(UserAddRecipe.this,0,0,search);
                lvUserIngredientsList.setAdapter(adapterIngredient);


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    public static String convertTo64Base(ImageView postImage) {
        Bitmap bitmap = ((BitmapDrawable) postImage.getDrawable()).getBitmap();

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] data = byteArrayOutputStream.toByteArray();

        return Base64.encodeToString(data, Base64.DEFAULT);
    }
    private Uri createUri() throws IOException {
        //int numOfPhoto=(int)(1000000*Math.random());
        //File imageFile=new File(getApplicationContext().getFilesDir(), "my_images.jpg");
        imageFile=createImageFile();
        return FileProvider.getUriForFile(getApplicationContext(),
                "com.example.recipe_finder.fileProvider",
                imageFile);
    }
    private File createImageFile() throws IOException {
        Calendar c=Calendar.getInstance();
        int year=c.get(Calendar.YEAR);
        int month=c.get(Calendar.MONTH)+1;
        int day=c.get(Calendar.DAY_OF_MONTH);
        int hour=c.get(Calendar.HOUR_OF_DAY);
        int minute=c.get(Calendar.MINUTE);
        int second=c.get(Calendar.SECOND);
        String timeStamp = ""+day+"_"+month+"_"+year+"_"+hour+"_"+minute+"_"+second;
        String imageFileName = "ZeFra_" + timeStamp;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }
}


