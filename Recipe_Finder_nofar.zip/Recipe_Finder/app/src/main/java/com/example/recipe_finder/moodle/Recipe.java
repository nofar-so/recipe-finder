package com.example.recipe_finder.moodle;

import java.util.ArrayList;

public class Recipe {
    private String id;
    private String name;
    private ArrayList<Ingredients> ingredients;
    private String PreparationMethod;
    private String creator;
    private String image;

    public Recipe(String id, String name, ArrayList<Ingredients> ingredients, String preparationMethod, String creator, String image) {
        this.id = id;
        this.name = name;
        this.ingredients = ingredients;
        PreparationMethod = preparationMethod;
        this.creator = creator;
        this.image = image;
    }

    public Recipe() {
    }



    public String getPreparationMethod() {
        return PreparationMethod;
    }

    public void setPreparationMethod(String preparationMethod) {
        PreparationMethod = preparationMethod;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return name;
    }

    public void setType(String name) {
        this.name = name;
    }

    public ArrayList getIngredients() {
        return this.ingredients;
    }

    public void setIngredients(ArrayList<Ingredients> ingredients) {
        this.ingredients = ingredients;
    }
    public  void AddIngredients(Ingredients ingredient){
        if(this.ingredients==null)
            this.ingredients = new ArrayList<>();
        this.ingredients.add(ingredient);
    }

    @Override
    public String toString() {
        return "Recipe{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", ingredients=" + ingredients +
                ", PreparationMethod='" + PreparationMethod + '\'' +
                ", creator='" + creator + '\'' +
                '}';
    }
}

