package com.example.recipe_finder.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterRecipes;
import com.example.recipe_finder.moodle.AppData;
import com.example.recipe_finder.moodle.Ingredients;
import com.example.recipe_finder.moodle.Recipe;
import com.example.recipe_finder.moodle.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserRecipeByIngredientsList extends AppCompatActivity {

    EditText etSearchRecipe;
    ListView lvRecipeListUser;
    private DatabaseReference database, userRef, favsRef;
    ArrayList<Recipe> recipes, search;
    AdapterRecipes adapterRecipes;
    User user;
    String uid;
    SharedPreferences sp;
    ArrayList<String> fav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_recipe_by_ingredients_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sp = getSharedPreferences("details1", 0);
        uid = sp.getString("uid", "");

        getUser();

        search = new ArrayList<>();
        Log.d("recipe list", "1");
        lvRecipeListUser = findViewById(R.id.lvRecipeListUser);
        etSearchRecipe = findViewById(R.id.etSearchRecipe);

        Log.d("recipe list", "2");
    }

    private void getUser() {
        userRef = FirebaseDatabase.getInstance().getReference("Users").child(uid);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                user = snapshot.getValue(User.class);
                getFavs(); // Always load favs, even if 0
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("TAG", "Failed to read user.", error.toException());
            }
        });
    }


    private void getFavs() {
        fav = new ArrayList<>();
        favsRef = FirebaseDatabase.getInstance().getReference("Favorites").child(uid);

        favsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    fav.add(snap.getKey()); // add favorite recipe IDs
                }
                retriveData(); // now get recipes
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("TAG", "Failed to read favorites.", error.toException());
            }
        });
    }

    private void retriveData() {
        database = FirebaseDatabase.getInstance().getReference("Recipes");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                recipes = new ArrayList<>();
                ArrayList<Ingredients> selectedIngredients = AppData.getInstance().getSelectedIngredients();

                Map<String, Integer> selectedMap = new HashMap<>();
                for (Ingredients selected : selectedIngredients) {
                    selectedMap.put(selected.getId(), selected.getAmount());
                }

                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Recipe r = data.getValue(Recipe.class);

                    if (r == null || r.getIngredients() == null || r.getCreator().equals(uid)) continue;

                    // Convert recipe ingredients from Firebase
                    List<Map<String, Object>> ingredientMaps = (List<Map<String, Object>>) data.child("ingredients").getValue();
                    List<Ingredients> recipeIngredients = new ArrayList<>();

                    if (ingredientMaps != null) {
                        for (Map<String, Object> map : ingredientMaps) {
                            Ingredients ing = new Ingredients();
                            ing.setId((String) map.get("id"));
                            ing.setName((String) map.get("name"));
                            Object amtObj = map.get("amount");
                            if (amtObj instanceof Long) {
                                ing.setAmount(((Long) amtObj).intValue());
                            } else if (amtObj instanceof Integer) {
                                ing.setAmount((Integer) amtObj);
                            }
                            recipeIngredients.add(ing);
                        }
                    }


                    boolean valid = true;
                    for (Ingredients recipeIng : recipeIngredients) {
                        if (!selectedMap.containsKey(recipeIng.getId())) {
                            valid = false;
                            break;
                        }
                        if (recipeIng.getAmount() > selectedMap.get(recipeIng.getId())) {
                            valid = false;
                            break;
                        }
                    }

                    if (valid) {
                        recipes.add(r);
                    }
                }

                search = new ArrayList<>(recipes);
                adapterRecipes = new AdapterRecipes(UserRecipeByIngredientsList.this, 0, 0, search, fav);
                lvRecipeListUser.setAdapter(adapterRecipes);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });

        lvRecipeListUser.setOnItemClickListener((adapterView, view, i, l) -> {
            Intent intent = new Intent(UserRecipeByIngredientsList.this, RecipeDetails.class);
            intent.putExtra("recipeId", search.get(i).getId());
            startActivity(intent);
        });

        etSearchRecipe.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etSearchRecipe.getText().toString().toLowerCase();
                ArrayList<Recipe> filtered = new ArrayList<>();
                for (Recipe recipe : recipes) {
                    if (recipe.getName().toLowerCase().contains(txt)) {
                        filtered.add(recipe);
                    }
                }
                adapterRecipes = new AdapterRecipes(UserRecipeByIngredientsList.this, 0, 0, filtered, fav);
                lvRecipeListUser.setAdapter(adapterRecipes);
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

}