package com.example.recipe_finder.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterRecipes;
import com.example.recipe_finder.moodle.Recipe;
import com.example.recipe_finder.moodle.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserRecipeList extends AppCompatActivity {

    EditText etSearchRecipeListUser;
    ListView lvRecipeListUser;
    Button btnAddRecipeUser;
    private DatabaseReference database, userRef, favsRef;
    ArrayList<Recipe> recipes, search;
    AdapterRecipes adapterRecipes;
    User user;
    String uid;
    SharedPreferences sp;
    ArrayList<String> fav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_recipe_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sp = getSharedPreferences("details1", 0);
        uid = sp.getString("uid", "");

        getUser();

        search= new ArrayList<>();
        Log.d("recipe list", "1");
        btnAddRecipeUser = findViewById(R.id.btnAddRecipeUser);
        lvRecipeListUser = findViewById(R.id.lvFavoritesListUser);
        etSearchRecipeListUser = findViewById(R.id.etSearchFavoritesListUser);
        btnAddRecipeUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserRecipeList.this, UserAddRecipe.class);
            }
        });


        Log.d("recipe list", "2");
    }

    private void getUser() {
        userRef = FirebaseDatabase.getInstance().getReference("Users").child(uid);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                user = snapshot.getValue(User.class);
                getFavs(); // Always load favs, even if 0
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("TAG", "Failed to read user.", error.toException());
            }
        });
    }


    private void getFavs() {
        fav = new ArrayList<>();
        favsRef = FirebaseDatabase.getInstance().getReference("Favorites").child(uid);

        favsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()) {
                    fav.add(snap.getKey()); // add favorite recipe IDs
                }
                retriveData(); // now get recipes
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("TAG", "Failed to read favorites.", error.toException());
            }
        });
    }

    private void retriveData() {
        database = FirebaseDatabase.getInstance().getReference("Recipes");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                recipes = new ArrayList<>();
                for(DataSnapshot data : dataSnapshot.getChildren())
                {
                    Recipe r = data.getValue(Recipe.class);
                    if(!r.getCreator().equals(uid)) // exclude own recipes
                        recipes.add(r);
                }
                search = new ArrayList<>(recipes);

                adapterRecipes = new AdapterRecipes(UserRecipeList.this, 0, 0, search, fav);
                lvRecipeListUser.setAdapter(adapterRecipes);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });


        lvRecipeListUser.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(UserRecipeList.this, RecipeDetails.class);
                intent.putExtra("recipeId", search.get(i).getId());
                startActivity(intent);
            }
        });
        btnAddRecipeUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserRecipeList.this, UserAddRecipe.class);
                startActivity(intent);
            }
        });


        etSearchRecipeListUser.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etSearchRecipeListUser.getText().toString().toLowerCase();
                search = new ArrayList<>();
                for(Recipe recipe : recipes) {
                    if(recipe.getName().toLowerCase().contains(txt)) {
                        search.add(recipe);
                    }
                }
                adapterRecipes = new AdapterRecipes(UserRecipeList.this, 0, 0, search, fav); // pass fav list here!
                lvRecipeListUser.setAdapter(adapterRecipes);
            }


            @Override
            public void afterTextChanged(Editable editable) {
                // No action needed here
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.user_menu,menu);

        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.users_recipe_list) {
            Intent intent = new Intent(this, UserRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_search_by_ingredient) {
            Intent intent = new Intent(this, UserIngredientsSelector.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.favorites) {
            Intent intent = new Intent(this, UserFavorites.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_own_recipes) {
            Intent intent = new Intent(this, UserRecipes.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_main) {
            Intent intent = new Intent(this, MainUser.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}