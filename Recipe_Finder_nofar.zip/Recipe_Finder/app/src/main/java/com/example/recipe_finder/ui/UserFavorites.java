package com.example.recipe_finder.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.AdapterRecipes;
import com.example.recipe_finder.moodle.Recipe;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserFavorites extends AppCompatActivity {

    EditText etSearchFavoritesListUser;
    ListView lvFavoritesListUser;
    ArrayList<Recipe> favoriteRecipes, search;
    AdapterRecipes adapterRecipes;
    private DatabaseReference favoritesDb, recipesDb;
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://recipefinder-63cc6557-default-rtdb.firebaseio.com/");
    private FirebaseAuth auth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_favorites);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvFavoritesListUser = findViewById(R.id.lvFavoritesListUser);
        etSearchFavoritesListUser = findViewById(R.id.etSearchFavoritesListUser);
        search = new ArrayList<>();
        Log.d("recipe list", "1");
        Log.d("recipe list", "2");
        auth = FirebaseAuth.getInstance();

        String userId = auth.getCurrentUser().getUid();
        favoritesDb = FirebaseDatabase.getInstance().getReference("Favorites").child(userId);

        favoriteRecipes = new ArrayList<>();
        lvFavoritesListUser.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(UserFavorites.this, RecipeDetails.class);
                intent.putExtra("recipeId", favoriteRecipes.get(i).getId());
                startActivity(intent);
            }
        });

        favoritesDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Clear existing data
                favoriteRecipes.clear();

                // Loop through the user's favorite recipes
                for (DataSnapshot favoriteSnapshot : snapshot.getChildren()) {
                    String recipeId = favoriteSnapshot.getKey();  // Get the recipeId from Favorites
                    getRecipeDetails(recipeId); // Fetch the full recipe details
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("UserFavorites", "Failed to read favorites: " + error.getMessage());
            }
        });
    }
    private void getRecipeDetails(String recipeId) {
        recipesDb = FirebaseDatabase.getInstance().getReference("Recipes").child(recipeId);

        recipesDb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Convert the snapshot into a Recipe object
                Recipe recipe = snapshot.getValue(Recipe.class);
                if (recipe != null) {
                    favoriteRecipes.add(recipe);  // Add the recipe to the list of favorite recipes
                    updateListView();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("UserFavorites", "Failed to fetch recipe details: " + error.getMessage());
            }
        });


        etSearchFavoritesListUser.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etSearchFavoritesListUser.getText().toString();
                search = new ArrayList<>();
                for(int j = 0; j < favoriteRecipes.size(); j++) {
                    if(favoriteRecipes.get(j).getName().contains(txt)) {
                        search.add(favoriteRecipes.get(j));
                    }
                }
                adapterRecipes = new AdapterRecipes(UserFavorites.this, 0, 0, search, new ArrayList<String>());
                lvFavoritesListUser.setAdapter(adapterRecipes);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // No action needed here
            }
        });

    }

    // Update the ListView with the list of favorite recipes
    private void updateListView() {
        // Use the Adapter to bind the data
        adapterRecipes = new AdapterRecipes(UserFavorites.this, 0, 0, favoriteRecipes, new ArrayList<>());
        lvFavoritesListUser.setAdapter(adapterRecipes);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.user_menu,menu);

        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.users_recipe_list) {
            Intent intent = new Intent(this, UserRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_search_by_ingredient) {
            Intent intent = new Intent(this, UserIngredientsSelector.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.favorites) {
            Intent intent = new Intent(this, UserFavorites.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_own_recipes) {
            Intent intent = new Intent(this, UserRecipes.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_main) {
            Intent intent = new Intent(this, MainUser.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}


