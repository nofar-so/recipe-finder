package com.example.recipe_finder.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterUsers;
import com.example.recipe_finder.moodle.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ManagerCancelledUsers extends AppCompatActivity {

    EditText etSearchCancelledList;
    ListView lvCancelledList;
    ArrayList<User> users, search;
    AdapterUsers adapterUsers;
    private DatabaseReference database;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_cancelled_users);
        lvCancelledList = findViewById(R.id.lvCancelledList);
        etSearchCancelledList = findViewById(R.id.etSearchCancelledList);

        lvCancelledList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                database = FirebaseDatabase.getInstance().getReference("Users").child(search.get(i).getId());
                database.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        // This method is called once with the initial value and again
                        // whenever data at this location is updated.
                        user = dataSnapshot.getValue(User.class);

                        user.setType("user");
                        database.setValue(user);
                        //editor.putString("fname",newUser.getFname());


                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Failed to read value
                        Log.w("TAG", "Failed to read value.", error.toException());
                    }
                });


                return false;
            }
        });


        etSearchCancelledList.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etSearchCancelledList.getText().toString();
                search = new ArrayList<>();
                for(int j=0;j<users.size();j++){
                    if(users.get(j).getlName().contains(txt))
                        search.add(users.get((j)));
                }
                adapterUsers = new AdapterUsers(ManagerCancelledUsers.this,0,0,search);
                lvCancelledList.setAdapter(adapterUsers);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        retriveData();
    }
    private void retriveData() {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");
        DatabaseReference favRef = FirebaseDatabase.getInstance().getReference("Favorites");

        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                users = new ArrayList<>();

                for (DataSnapshot data : snapshot.getChildren()) {
                    User u = data.getValue(User.class);
                    if (u != null && u.getType().equals("cancelled")) {
                        u.setId(data.getKey()); // Set user ID
                        users.add(u);
                    }
                }

                // Fetch favorite counts
                favRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot favSnapshot) {
                        for (User user : users) {
                            DataSnapshot userFavs = favSnapshot.child(user.getId());
                            user.setFavorites((int) userFavs.getChildrenCount()); // Set favorite count
                        }

                        // Update UI
                        search = users;
                        adapterUsers = new AdapterUsers(ManagerCancelledUsers.this, 0, 0, search);
                        lvCancelledList.setAdapter(adapterUsers);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Log.e("FAV_LOAD", "Failed to load favorites", error.toException());
                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.e("USER_LOAD", "Failed to load users", error.toException());
            }
        });

}
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.manager_menu,menu);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.recipe_list) {
            Intent intent = new Intent(this, ManagerRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.add_recipe) {
            Intent intent = new Intent(this, ManagerAddRecipe.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_list) {
            Intent intent = new Intent(this, ManagerUsersList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.cancelled_users) {
            Intent intent = new Intent(this, ManagerCancelledUsers.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_main) {
            Intent intent = new Intent(this, ManagerMain.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}