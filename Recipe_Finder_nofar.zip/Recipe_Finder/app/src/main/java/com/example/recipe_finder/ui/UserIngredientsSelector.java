package com.example.recipe_finder.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.AppData;
import com.example.recipe_finder.moodle.Ingredients;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserIngredientsSelector extends AppCompatActivity {

    SharedPreferences sp;
    String type;
    Button btnSearchRecipeByIngredients;
    ListView lvUserIngredientsList, lvIngredientsInRecipeUser;
    EditText etSearchIngredient;
    ArrayList<Ingredients> ingredients, ingredientsInRecipe, search;
    AdapterIngredient adapterIngredient, adapterIngredientInRecipe;
    private DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_ingredients_selector);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sp = getSharedPreferences("details1", 0);
        type = sp.getString("type", "");

        btnSearchRecipeByIngredients = findViewById(R.id.btnSearchRecipeByIngredients);
        etSearchIngredient = findViewById(R.id.etSearchIngredient);
        lvUserIngredientsList = findViewById(R.id.lvUserIngredientsList);
        lvIngredientsInRecipeUser = findViewById(R.id.lvIngredientsInRecipeUser);

        ingredients = new ArrayList<>();
        ingredientsInRecipe = new ArrayList<>();
        search = new ArrayList<>();

        database = FirebaseDatabase.getInstance().getReference("Ingredients");

        btnSearchRecipeByIngredients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Save selected ingredients to singleton
                AppData.getInstance().setSelectedIngredients(new ArrayList<>(ingredientsInRecipe));

                // Move to the next screen
                Intent intent = new Intent(UserIngredientsSelector.this, UserRecipeByIngredientsList.class);
                startActivity(intent);
            }
        });

        lvUserIngredientsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ingredients ingredient = search.get(position);
                boolean exists = false;

                for (Ingredients i : ingredientsInRecipe) {
                    if (i.getId().equals(ingredient.getId())) {
                        i.setAmount(i.getAmount() + 1);
                        exists = true;
                        break;
                    }
                }

                if (!exists) {
                    Ingredients newIngredient = new Ingredients(ingredient.getId(), ingredient.getName(), 1);
                    ingredientsInRecipe.add(newIngredient);
                }

                adapterIngredientInRecipe = new AdapterIngredient(UserIngredientsSelector.this, 0, 0, ingredientsInRecipe);
                lvIngredientsInRecipeUser.setAdapter(adapterIngredientInRecipe);
            }
        });

        lvIngredientsInRecipeUser.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ingredients selected = ingredientsInRecipe.get(position);
                if (selected.getAmount() > 1) {
                    selected.setAmount(selected.getAmount() - 1);
                } else {
                    ingredientsInRecipe.remove(position);
                }
                adapterIngredientInRecipe = new AdapterIngredient(UserIngredientsSelector.this, 0, 0, ingredientsInRecipe);
                lvIngredientsInRecipeUser.setAdapter(adapterIngredientInRecipe);
            }
        });

        etSearchIngredient.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence s, int j, int i1, int i2) {
                String query = etSearchIngredient.getText().toString().toLowerCase();
                search = new ArrayList<>();

                for (Ingredients i : ingredients) {
                    if (i.getName().toLowerCase().contains(query)) {
                        search.add(i);
                    }
                }

                adapterIngredient = new AdapterIngredient(UserIngredientsSelector.this, 0, 0, search);
                lvUserIngredientsList.setAdapter(adapterIngredient);
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        retrieveIngredients();
    }

    private void retrieveIngredients() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                ingredients = new ArrayList<>();
                for (DataSnapshot data : snapshot.getChildren()) {
                    Ingredients i = data.getValue(Ingredients.class);
                    if (i != null) {
                        ingredients.add(i);
                    }
                }

                search = new ArrayList<>(ingredients);
                adapterIngredient = new AdapterIngredient(UserIngredientsSelector.this, 0, 0, search);
                lvUserIngredientsList.setAdapter(adapterIngredient);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Handle error
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.user_menu,menu);

        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.users_recipe_list) {
            Intent intent = new Intent(this, UserRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_search_by_ingredient) {
            Intent intent = new Intent(this, UserIngredientsSelector.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.favorites) {
            Intent intent = new Intent(this, UserFavorites.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_own_recipes) {
            Intent intent = new Intent(this, UserRecipes.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_main) {
            Intent intent = new Intent(this, MainUser.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}
