package com.example.recipe_finder.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.Person;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LogIn extends AppCompatActivity implements View.OnClickListener {

    EditText etEmail, etPassword;
    Button btnLogin;
    TextView tvRegister;
    private FirebaseAuth mAuth;
    SharedPreferences sp;
    String strMail, strPass;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef;
    Person newUser;
    String Mail, Pass, uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);

        mAuth = FirebaseAuth.getInstance();
        sp = getSharedPreferences("details1", 0);
        strMail = sp.getString("mail", "");
        strPass = sp.getString("pass", "");
        etEmail.setText(strMail);
        etPassword.setText(strPass);

        btnLogin.setOnClickListener(this);

        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LogIn.this, Register.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onClick(View view) {
        Mail=etEmail.getText().toString();
        Pass=etPassword.getText().toString();
        mAuth.signInWithEmailAndPassword(Mail, Pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("TAG", "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            uid = user.getUid();
                            Log.d("TAG", user.getUid());
                            myRef = database.getReference("Users").child(uid);
                            // Read from the database
                            myRef.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    // This method is called once with the initial value and again
                                    // whenever data at this location is updated.
                                    newUser = dataSnapshot.getValue(Person.class);
                                    Log.d("TAG", "Value is: " + newUser.getfName());
                                    SharedPreferences.Editor editor=sp.edit();
                                    //editor.putString("fname",newUser.getFname());
                                    editor.putString("uid",uid);
                                    //editor.putString("lname",newUser.getLname());
                                    editor.putString("mail",Mail);
                                    editor.putString("type", newUser.getType());
                                    editor.putString("pass",Pass);

                                    editor.commit();
                                    if(newUser.getType().equals("manager")){
                                        Intent intent = new Intent(LogIn.this, ManagerMain.class);
                                        startActivity(intent);
                                    }
                                    else {
                                        Intent intent = new Intent(LogIn.this, MainUser.class);
                                        startActivity(intent);
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError error) {
                                    // Failed to read value
                                    Log.w("TAG", "Failed to read value.", error.toException());
                                }
                            });

                            //updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("TAG", "signInWithEmail:failure", task.getException());
                            Toast.makeText(LogIn.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            //updateUI(null);
                        }

                        // ...
                    }
                });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu,menu);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.login) {
            Intent intent = new Intent(this, LogIn.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.register) {
            Intent intent = new Intent(this, Register.class);
            startActivity(intent);
            return true;

        } else if (id == R.id.about) {
            Intent intent = new Intent(this, About.class);
            startActivity(intent);
            return true;

        } else if (id == R.id.home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;

        }
        return true;
    }
}