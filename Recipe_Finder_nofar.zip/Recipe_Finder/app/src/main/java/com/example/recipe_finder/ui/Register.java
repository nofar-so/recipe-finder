package com.example.recipe_finder.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.Person;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity implements View.OnClickListener {


    EditText etEmail, etPassword, etFname, etLname, etPhone;
    String fName, lName, Email, Phone, Password, id;
    Button btnRegister;
    TextView tvLogin;

    private FirebaseAuth mAuth;
    SharedPreferences sp;
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://recipefinder-63cc6557-default-rtdb.firebaseio.com/");
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mAuth = FirebaseAuth.getInstance();
        sp = getSharedPreferences("details1", 0);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        etFname = findViewById(R.id.etFname);
        etLname = findViewById(R.id.etLname);
        etPhone = findViewById(R.id.etPhone);
        tvLogin = findViewById(R.id.tvLogin);


        btnRegister.setOnClickListener(this);


        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this, LogIn.class);
                startActivity(intent);
            }
        });
    }



    @Override
    public void onClick(View view) {
        Email = etEmail.getText().toString();
        fName = etFname.getText().toString();
        lName = etLname.getText().toString();
        Password = etPassword.getText().toString();
        Phone = etPhone.getText().toString();
        myRef = database.getReference("Users");
        if (fName.equals(""))
            Toast.makeText(Register.this, "לא מילאת שם פרטי", Toast.LENGTH_LONG).show();
        else if (lName.equals(""))
            Toast.makeText(Register.this, "לא מילאת שם משפחה", Toast.LENGTH_LONG).show();
        else if (Email.equals(""))
            Toast.makeText(Register.this, "לא מילאת דואר אלקטרוני", Toast.LENGTH_LONG).show();
        else if (Password.equals(""))
            Toast.makeText(Register.this, "לא מילאת סיסמה", Toast.LENGTH_LONG).show();
        else if (Phone.equals(""))
            Toast.makeText(Register.this, "לא מילאת טלפון", Toast.LENGTH_LONG).show();
        else {
            mAuth.createUserWithEmailAndPassword(Email, Password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {

                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        Person newUser = new Person(user.getUid(), fName, lName, Email, Password, Phone);
                        myRef = database.getReference("Users").child(user.getUid());
                        myRef.setValue(newUser);
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putString("fname", fName);
                        editor.putString("uid", user.getUid());
                        editor.putString("lname", lName);
                        editor.putString("mail", Email);
                        editor.putString("password", Password);
                        editor.putString("type", "user");
                        editor.commit();
                        Intent intent = new Intent(Register.this, MainUser.class);
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(Register.this, "אימייל או סיסמה לא תקינים", Toast.LENGTH_LONG).show();
                    }

                }
            });
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu,menu);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.login) {
            Intent intent = new Intent(this, LogIn.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.register) {
            Intent intent = new Intent(this, Register.class);
            startActivity(intent);
            return true;

        } else if (id == R.id.about) {
            Intent intent = new Intent(this, About.class);
            startActivity(intent);
            return true;

        } else if (id == R.id.home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;

        }
        return true;
    }


}


