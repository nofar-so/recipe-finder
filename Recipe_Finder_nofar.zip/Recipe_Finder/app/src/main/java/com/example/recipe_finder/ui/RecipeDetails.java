package com.example.recipe_finder.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.Recipe;
import com.example.recipe_finder.moodle.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RecipeDetails extends AppCompatActivity {

    TextView NameDetails, IngredientsDetails, CreatorDetails, PreparationMethodDetails;
    LottieAnimationView likeButton;
    boolean isFavorite = false;
    Intent get;
    String recipeId;
    private DatabaseReference favoritesDb;
    private FirebaseDatabase database = FirebaseDatabase.getInstance("https://recipefinder-63cc6557-default-rtdb.firebaseio.com/");
    private FirebaseAuth auth;
    Recipe recipe;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_recipe_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI elements
        NameDetails = findViewById(R.id.NameDetails);
        IngredientsDetails = findViewById(R.id.IngredientsDetails);
        CreatorDetails = findViewById(R.id.CreatorDetails);
        PreparationMethodDetails = findViewById(R.id.PreparationMethodDetails);
        likeButton = findViewById(R.id.likeButton);

        auth = FirebaseAuth.getInstance();
        get = getIntent();
        recipeId = get.getStringExtra("recipeId");

        favoritesDb = FirebaseDatabase.getInstance()
                .getReference("Favorites")
                .child(auth.getCurrentUser().getUid());

        sp = getSharedPreferences("details1", 0);

        // Begin loading the recipe by scanning through all Recipes
        loadRecipeAndCreator();

        // Like button listener
        likeButton.setOnClickListener(v -> {
            if (isFavorite) {
                removeFavorite();
            } else {
                addFavorite();
            }
        });
    }

    private void loadRecipeAndCreator() {
        DatabaseReference recipeRef = database.getReference("Recipes").child(recipeId);

        recipeRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                recipe = snapshot.getValue(Recipe.class);

                if (recipe != null) {
                    NameDetails.setText(recipe.getName());
                    IngredientsDetails.setText(recipe.getIngredients()+"");
                    PreparationMethodDetails.setText(recipe.getPreparationMethod());

                    String creatorId = recipe.getCreator(); // This is the user ID stored inside the recipe
                    loadCreatorName(creatorId);
                    checkIfFavorite();
                } else {
                    NameDetails.setText("Recipe not found.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                NameDetails.setText("Error loading recipe.");
            }
        });
    }


    private void loadCreatorName(String creatorId) {
        Log.d("DEBUG", "Looking for user with ID: " + creatorId);

        DatabaseReference userRef = database.getReference("Users").child(creatorId);

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot userSnap) {
                if (userSnap.exists()) {
                    User creator = userSnap.getValue(User.class);
                    if (creator != null && creator.getfName() != null) {
                        CreatorDetails.setText("Created by: " + creator.getfName());
                    } else {
                        CreatorDetails.setText("Creator data incomplete.");
                    }
                } else {
                    CreatorDetails.setText("Creator not found in Users.");
                    Log.d("DEBUG", "User ID not found in Users node: " + creatorId);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                CreatorDetails.setText("Error loading creator.");
            }
        });
    }


    private void checkIfFavorite() {
        favoritesDb.child(recipeId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                isFavorite = snapshot.exists();
                updateLikeButton();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void addFavorite() {
        favoritesDb.child(recipeId).setValue(true);
        isFavorite = true;
        updateLikeButton();

        likeButton.setSpeed(1f); // play forward
        likeButton.playAnimation();
    }

    private void removeFavorite() {
        favoritesDb.child(recipeId).removeValue();
        isFavorite = false;
        updateLikeButton();

        likeButton.setSpeed(-3f); // play in reverse
        likeButton.playAnimation();
    }

    private void updateLikeButton() {
        likeButton.setProgress(isFavorite ? 1f : 0f);
    }
}
