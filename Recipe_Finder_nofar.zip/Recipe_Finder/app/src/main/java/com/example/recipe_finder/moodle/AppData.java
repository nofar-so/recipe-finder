package com.example.recipe_finder.moodle;

import java.util.ArrayList;

public class AppData {
    private static AppData instance;
    private ArrayList<Ingredients> selectedIngredients;

    private AppData() {
        selectedIngredients = new ArrayList<>();
    }

    public static AppData getInstance() {
        if (instance == null) {
            instance = new AppData();
        }
        return instance;
    }

    public ArrayList<Ingredients> getSelectedIngredients() {
        return selectedIngredients;
    }

    public void setSelectedIngredients(ArrayList<Ingredients> selectedIngredients) {
        this.selectedIngredients = selectedIngredients;
    }
}
