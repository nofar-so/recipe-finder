package com.example.recipe_finder.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.Ingredients;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import android.text.TextWatcher;


public class ManagerIngredientsList extends AppCompatActivity {

    EditText etSearchIngredient;
    ListView lvIngredientsList;
    Button btnGoToAddIngredient;
    private DatabaseReference database, deleteRef;
    ArrayList<Ingredients> ingredients, search;
    AdapterIngredient adapterIngredient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manager_ingredients_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnGoToAddIngredient = findViewById(R.id.btnGoToAddIngredient);
        etSearchIngredient = findViewById(R.id.etSearchIngredient);
        lvIngredientsList = findViewById(R.id.lvIngredientsList);
        ingredients = new ArrayList<>();
        search = new ArrayList<>();
        database = FirebaseDatabase.getInstance().getReference("Ingredients");

        btnGoToAddIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerIngredientsList.this, ManagerAddIngredients.class);
                startActivity(intent);
            }
        });


        etSearchIngredient.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String txt = etSearchIngredient.getText().toString();
                search = new ArrayList<>();
                for(int j=0;j<ingredients.size();j++){
                    if(ingredients.get(j).getName().contains(txt))
                        search.add(ingredients.get((j)));
                }
                adapterIngredient = new AdapterIngredient(ManagerIngredientsList.this,0,0,search);
                lvIngredientsList.setAdapter(adapterIngredient);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        lvIngredientsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteRef = FirebaseDatabase.getInstance().getReference("Ingredients").child(search.get(position).getId());
                deleteRef.removeValue();

                return false;
            }
        });
        retriveData();

    }
    private void retriveData() {
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                ingredients = new ArrayList<>();
                for(DataSnapshot data : dataSnapshot.getChildren())
                {
                    Ingredients i = data.getValue(Ingredients.class);
                    ingredients.add(i);

                }
                search = ingredients;
                adapterIngredient = new AdapterIngredient(ManagerIngredientsList.this,0,0,search);
                lvIngredientsList.setAdapter(adapterIngredient);


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}