package com.example.recipe_finder.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.Ingredients;
import com.example.recipe_finder.moodle.Recipe;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;

//public class ManagerUpdateRecipe extends AppCompatActivity {
//    EditText etNameUpdate, etIngredientsUpdate, etCreatorUpdate, etPreparationMethodUpdate;
//    Button btnUpdateRecipe;
//    Intent get;
//    String recipeId;
//    private DatabaseReference database;
//    Recipe recipe;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_manager_update_recipe);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//
//        });
//        btnUpdateRecipe = findViewById(R.id.btnUpdateRecipe);
//        etNameUpdate = findViewById(R.id.etNameUpdate);
//        etIngredientsUpdate = findViewById(R.id.etIngredientsUpdate);
//        etCreatorUpdate = findViewById(R.id.etCreatorUpdate);
//        etPreparationMethodUpdate = findViewById(R.id.etPreparationMethodUpdate);
//        get = getIntent();
//        recipeId = get.getStringExtra("recipeId");
//        database = FirebaseDatabase.getInstance().getReference("Recipes").child(recipeId);
//        database.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                recipe = snapshot.getValue(Recipe.class);
//                etNameUpdate.setText(recipe.getName());
//                etIngredientsUpdate.setText(recipe.getIngredients()+"");
//                etCreatorUpdate.setText(recipe.getCreator()+"");
//                etPreparationMethodUpdate.setText(recipe.getPreparationMethod()+"");
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//        btnUpdateRecipe.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                    Recipe r = new Recipe(recipeId, etNameUpdate.getText().toString(), recipe.getIngredients(), etCreatorUpdate.getText().toString(), etPreparationMethodUpdate.getText().toString(), recipe.getImage());
//                    database = FirebaseDatabase.getInstance().getReference("Recipes").child(recipeId);
//                    database.setValue(r);
//
//                finish();
//            }
//        });
//
//    }
//}



public class ManagerUpdateRecipe extends AppCompatActivity {

    EditText etNameUpdate, etPreparationMethodUpdate;
    Button btnUpdateRecipe;
    Intent get;
    String recipeId;
    private DatabaseReference database;
    ArrayList<Ingredients> ingredients, ingredientsInRecipe;
    AdapterIngredient adapterIngredient, adapterIngredientInRecipe;
    Recipe recipe;
    ListView lvIngredientsInRecipeUpdate, lvIngredientsListUpdate;
    boolean isExist = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manager_update_recipe);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnUpdateRecipe = findViewById(R.id.btnUpdateRecipe);
        etNameUpdate = findViewById(R.id.etNameUpdate);
        lvIngredientsListUpdate = findViewById(R.id.lvIngredientsListUpdate);
        lvIngredientsInRecipeUpdate = findViewById(R.id.lvIngredientsInRecipeUpdate);
        etPreparationMethodUpdate = findViewById(R.id.etPreparationMethodUpdate);

        get = getIntent();
        recipeId = get.getStringExtra("recipeId");

        database = FirebaseDatabase.getInstance().getReference("Recipes").child(recipeId);

        // Retrieve recipe data
        database.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                recipe = snapshot.getValue(Recipe.class);
                if (recipe != null) {
                    etNameUpdate.setText(recipe.getName());
                    etPreparationMethodUpdate.setText(recipe.getPreparationMethod() + "");
                    if (recipe.getIngredients() != null)
                        ingredientsInRecipe = recipe.getIngredients();
                    retrieveIngredients();
                } else {
                    Toast.makeText(ManagerUpdateRecipe.this, "Recipe not found", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        btnUpdateRecipe.setOnClickListener(view -> {
            if (etNameUpdate.getText().toString().equals("") || etPreparationMethodUpdate.getText().toString().equals("") || ingredientsInRecipe == null || ingredientsInRecipe.size() == 0) {
                Toast.makeText(ManagerUpdateRecipe.this, "Please fill in all details", Toast.LENGTH_LONG).show();
            } else {
                recipe.setIngredients(ingredientsInRecipe);
                recipe.setName(etNameUpdate.getText().toString());
                recipe.setPreparationMethod(etPreparationMethodUpdate.getText().toString());
                database.setValue(recipe);
                finish();
            }
        });
    }

    // Retrieve all ingredients from Firebase
    private void retrieveIngredients() {
        DatabaseReference ingredientsRef = FirebaseDatabase.getInstance().getReference("Ingredients");

        ingredientsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ingredients = new ArrayList<>();
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Ingredients ingredient = data.getValue(Ingredients.class);
                    boolean isExistInRecipe = false;

                    // Check if ingredient is already in the recipe
                    for (Ingredients existingIngredient : ingredientsInRecipe) {
                        if (existingIngredient.getId().equals(ingredient.getId())) {
                            // Set the amount to what is in the recipe (already added)
                            ingredient.setAmount(existingIngredient.getAmount());
                            isExistInRecipe = true;
                            break;
                        }
                    }

                    // If ingredient is not in recipe, add it to the list of available ingredients
                    if (!isExistInRecipe) {
                        ingredient.setAmount(0); // Default amount is 0 for ingredients not in the recipe yet
                    }
                    ingredients.add(ingredient); // Add ingredient to available ingredients list
                }

                // Notify the adapter that the ingredients list has been updated
                adapterIngredient = new AdapterIngredient(ManagerUpdateRecipe.this, 0, 0, ingredients);
                lvIngredientsListUpdate.setAdapter(adapterIngredient);
                adapterIngredient.notifyDataSetChanged();

                // Set up the list of ingredients already in the recipe
                adapterIngredientInRecipe = new AdapterIngredient(ManagerUpdateRecipe.this, 0, 0, ingredientsInRecipe);
                lvIngredientsInRecipeUpdate.setAdapter(adapterIngredientInRecipe);
                adapterIngredientInRecipe.notifyDataSetChanged();

                // Set up click and long-click listeners for both lists
                setupIngredientClickListener();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("FirebaseError", "Error fetching ingredients: " + databaseError.getMessage());
            }
        });
    }


    // Handle adding/removing ingredients
    private void setupIngredientClickListener() {
        lvIngredientsListUpdate.setOnItemClickListener((parent, view, position, id) -> {
            Ingredients ingredient = ingredients.get(position);
            boolean isExist = false;

            // Check if ingredient is already in the recipe
            for (int i = 0; i < ingredientsInRecipe.size(); i++) {
                if (ingredientsInRecipe.get(i).getId().equals(ingredient.getId())) {
                    ingredientsInRecipe.get(i).setAmount(ingredientsInRecipe.get(i).getAmount() + 1); // Increase amount by 1
                    isExist = true;
                    break;
                }
            }

            // If ingredient isn't in recipe, add it
            if (!isExist) {
                ingredient.setAmount(1); // Set the initial amount to 1
                ingredientsInRecipe.add(ingredient);
            }

            adapterIngredientInRecipe.notifyDataSetChanged(); // Notify the adapter to refresh the ListView
        });

        // Handle long click to remove ingredient (decrement amount or remove)
        lvIngredientsInRecipeUpdate.setOnItemLongClickListener((parent, view, position, id) -> {
            Ingredients ingredient = ingredientsInRecipe.get(position);

            // Decrease amount if greater than 1, or remove if it's 1
            if (ingredient.getAmount() > 1) {
                ingredient.setAmount(ingredient.getAmount() - 1);
            } else {
                ingredientsInRecipe.remove(position);
            }

            adapterIngredientInRecipe.notifyDataSetChanged(); // Refresh the ListView
            return true;  // Return true to indicate the long click is handled
        });
    }
}


