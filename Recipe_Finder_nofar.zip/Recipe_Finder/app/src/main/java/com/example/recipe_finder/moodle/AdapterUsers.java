package com.example.recipe_finder.moodle;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.recipe_finder.R;

import java.util.List;

public class AdapterUsers extends ArrayAdapter<User> {
    Context context;//העמוד שממנו היתה הקריאה לאדפטר
    List<User> objects;//רשימה של קבצי התמונה

    public AdapterUsers(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<User> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = ((Activity)context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.user_for_list, parent, false);

        TextView tvFullName = view.findViewById(R.id.tvFullName);
        TextView tvUserMail = view.findViewById(R.id.tvUserMail);
        TextView tvUserPhone = view.findViewById(R.id.tvUserPhone);
        TextView tvNumOfFavs = view.findViewById(R.id.tvNumOfFavs);

        User temp = objects.get(position);

        tvFullName.setText(temp.getfName()+ " " + temp.getlName());
        tvUserMail.setText("email: " +temp.getEmail());
        tvUserPhone.setText("phone: " + temp.getPhone());

        tvNumOfFavs.setText("num of favorites: " + temp.getFavorites());


        return view;
    }
}
