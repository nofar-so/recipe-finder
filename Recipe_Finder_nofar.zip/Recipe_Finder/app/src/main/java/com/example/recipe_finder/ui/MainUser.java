package com.example.recipe_finder.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterIngredient;
import com.example.recipe_finder.moodle.AdapterRecipes;
import com.example.recipe_finder.moodle.Ingredients;
import com.example.recipe_finder.moodle.Recipe;
import com.example.recipe_finder.moodle.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainUser extends AppCompatActivity {

    TextView tvMainUserHeader;
    Button btnUserFavoritesPage, btnUserRecipesPage, btnUserSearchPage, btnUserSearchByIngredients;
    private DatabaseReference database, userRef;
    SharedPreferences sp;
    String uid;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_user);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sp = getSharedPreferences("details1", 0);
        uid = sp.getString("uid", "");
        getUser();




        btnUserFavoritesPage = findViewById(R.id.btnUserFavoritesPage);
        btnUserRecipesPage = findViewById(R.id.btnUserRecipesPage);
        btnUserSearchPage = findViewById(R.id.btnUserSearchPage);
        tvMainUserHeader = findViewById(R.id.tvMainUserHeader);
        btnUserSearchByIngredients = findViewById(R.id.btnUserSearchByIngredients);
        //uId = get.getStringExtra("uId");
        //database = FirebaseDatabase.getInstance().getReference("Users").child(uId);

        btnUserSearchPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainUser.this, UserRecipeList.class);
                startActivity(intent);
            }
        });
        btnUserRecipesPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainUser.this, UserRecipes.class);
                startActivity(intent);
            }
        });
        btnUserFavoritesPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainUser.this, UserFavorites.class);
                startActivity(intent);
            }
        });

        btnUserSearchByIngredients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainUser.this, UserIngredientsSelector.class);
                startActivity(intent);
            }
        });


    }
    private void getUser() {
        userRef = FirebaseDatabase.getInstance().getReference("Users").child(uid);
        // Read from the database
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                user = dataSnapshot.getValue(User.class);
                tvMainUserHeader.setText("hello, " + user.getfName());

                Log.d("TAG", "Value is: " + user.getfName());
                SharedPreferences.Editor editor = sp.edit();
                //editor.putString("fname",newUser.getFname());


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.user_menu,menu);

        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.users_recipe_list) {
            Intent intent = new Intent(this, UserRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_search_by_ingredient) {
            Intent intent = new Intent(this, UserIngredientsSelector.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.favorites) {
            Intent intent = new Intent(this, UserFavorites.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_own_recipes) {
            Intent intent = new Intent(this, UserRecipes.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_main) {
            Intent intent = new Intent(this, MainUser.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.user_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}