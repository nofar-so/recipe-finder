package com.example.recipe_finder.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.recipe_finder.R;
import com.example.recipe_finder.moodle.AdapterRecipes;
import com.example.recipe_finder.moodle.Recipe;
import com.example.recipe_finder.moodle.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ManagerUsersDetails extends AppCompatActivity {

    TextView tvManagerUserDetailsName, tvManagerUserDetailsMail, tvManagerUserDetailsPhone, tvManagerUserDetailsNumOfFavs;
    ListView lvManagerUserDetailsfRecipes;
    String uid;
    private DatabaseReference database, userRef;
    AdapterRecipes adapterRecipes;
    ArrayList<Recipe> recipeArrayList;
    User user;
    Intent get;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_users_details);
        tvManagerUserDetailsMail = findViewById(R.id.tvManagerUserDetailsMail);
        tvManagerUserDetailsName = findViewById(R.id.tvManagerUserDetailsName);
        tvManagerUserDetailsPhone = findViewById(R.id.tvManagerUserDetailsPhone);
        tvManagerUserDetailsNumOfFavs = findViewById(R.id.tvManagerUserDetailsNumOfFavs);
        lvManagerUserDetailsfRecipes = findViewById(R.id.lvManagerUserDetailsfRecipes);

        get = getIntent();
        uid = get.getStringExtra("uid");
        getUser();;

    }
    private void getUser() {
        userRef = FirebaseDatabase.getInstance().getReference("Users").child(uid);
        // Read from the database
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                user = dataSnapshot.getValue(User.class);
                tvManagerUserDetailsName.setText("הפרטים של: , " + user.getfName() + " " + user.getlName());
                tvManagerUserDetailsMail.setText(user.getEmail());
                tvManagerUserDetailsPhone.setText(user.getPhone());

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });


    }

    private void getRecipes() {
        database = FirebaseDatabase.getInstance().getReference("Recipes");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                recipeArrayList = new ArrayList<>();
                for(DataSnapshot data: snapshot.getChildren()){
                    Recipe recipe = data.getValue(Recipe.class);
                }
                adapterRecipes = new AdapterRecipes(ManagerUsersDetails.this, 0, 0, recipeArrayList, new ArrayList<String>());

                lvManagerUserDetailsfRecipes.setAdapter(adapterRecipes);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.manager_menu,menu);

        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.recipe_list) {
            Intent intent = new Intent(this, ManagerRecipeList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.add_recipe) {
            Intent intent = new Intent(this, ManagerAddRecipe.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.users_list) {
            Intent intent = new Intent(this, ManagerUsersList.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.cancelled_users) {
            Intent intent = new Intent(this, ManagerCancelledUsers.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_main) {
            Intent intent = new Intent(this, ManagerMain.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.manager_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return true;
    }
}